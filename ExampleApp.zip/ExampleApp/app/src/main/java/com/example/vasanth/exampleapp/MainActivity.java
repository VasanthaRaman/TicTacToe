package com.example.vasanth.exampleapp;

import android.support.annotation.DrawableRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.Toast;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    //int rr;
    //0=x;1=o;
    int activePlayer=0;
    int[] gamestate={2,2,2,2,2,2,2,2,2,2};
    int[][] winningpositions={{1,2,3},{4,5,6},{7,8,9},{1,4,7},{2,5,8},{3,6,9},{1,5,9},{3,5,7}};
    boolean gameactive=true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // rr=ret();
    }
  /*  public int ret()
    {
        Random r = new Random();
        int r1=r.nextInt(20);
        return r1;
    } */
  /*  public void clickFn(View view)
    {
        Log.i("info", "button works");
        EditText nameEditText=(EditText) findViewById(R.id.nameEditText);
        int rs= Integer.parseInt(nameEditText.getText().toString());
        if(rs<rr)
        Toast.makeText(this, "upper", Toast.LENGTH_SHORT).show();
        else if(rs>rr)
            Toast.makeText(this, "lower", Toast.LENGTH_SHORT).show();
        else
        {    Toast.makeText(this, "Correct.Try again with new num", Toast.LENGTH_SHORT).show();
             rr=ret();
        }

    } */
    public void imgclickFn(View view)
    {
      //  ImageView imageView1=(ImageView) findViewById(R.id.imageView1);
      //  imageView1.setTranslationX(-2000);
        //imageView.animate().translationXBy(3000);
        ImageView counter=(ImageView)(view);
        int tapper = Integer.parseInt(counter.getTag().toString());
        if(gamestate[tapper]==2 && gameactive) {
            gamestate[tapper] = activePlayer;
            if (activePlayer == 0) {
                counter.setImageResource(R.drawable.tttx);
                activePlayer = 1;
            } else if (activePlayer == 1) {
                counter.setImageResource(R.drawable.ttto);
                activePlayer = 0;
            }
            counter.setTranslationY(-1500);
            counter.animate().translationYBy(1500).rotation(1800).setDuration(1000);
        for(int[] winning : winningpositions)
        {
            if(gamestate[winning[0]]==gamestate[winning[1]]&&gamestate[winning[1]]==gamestate[winning[2]]&&gamestate[winning[0]]!=2)
             { String winner=" ";
               if(activePlayer==1)
                   winner="X";
               else
                   winner="O";
                Toast.makeText(this, winner+" has won", Toast.LENGTH_SHORT).show();
                gameactive=false;
                 Button playagain=(Button) findViewById(R.id.button);
                 playagain.setVisibility(View.VISIBLE);
            }
        }

        }
    }
    public void buttonclickFn(View view)
    {
        Button playagain=(Button) findViewById(R.id.button);
        playagain.setVisibility(View.INVISIBLE);
        android.support.v7.widget.GridLayout mygrid= findViewById(R.id.gridLayout);
        for(int i=0;i<mygrid.getChildCount();i++)
        {
            ImageView counter = (ImageView) mygrid.getChildAt(i);
            counter.setImageDrawable(null);
            gameactive=true;
            activePlayer=0;
            for(int k=0;k<gamestate.length;k++)
            {
                gamestate[k]=2;
            }
        }

    }
}
